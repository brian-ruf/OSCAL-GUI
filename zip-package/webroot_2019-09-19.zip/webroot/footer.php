

<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>

<footer id='footer-area' class='site-footer' style=' position: fixed; left: 0; bottom: 0; width: 100%; background-color: black;'>

	<div style='text-align: center; align: center; margin: 0 auto;'>

		<table style='border: 0;margin:0; width:100%;  background-color: black; padding: 0;'>

		<tr>
			<td style='width: 2%;'>&nbsp;</td>
			<td style='width; 47%;'>
				<a href='https://www.nist.gov' target='_blank'><img src='./img/NIST_logo_rev.png' alt="National Institute of Standards and Technology logo" /></a>
			</td>
			<td style='width: 2%;'>&nbsp;</td>
			<td style='width: 47%; color: #E31C3D; background-color:white; text-align:center; font-size:20px; font-weight: bold; font-family: Calibri, sans-serif;'>
				<!-- img src='./img/FedRAMP logo_Option 2_no_tagline.png' style='width:132px;height:132px;' alt="Federal Risk and Authorizaton Management Program (FedRAMP) logo" / -->
				<a href='https://www.fedramp.gov' target='_blank' style='font-size:16px; text-decoration:none; color:#E31C3D;'>
				<img src='./img/logo-main-fedramp.png' alt="Federal Risk and Authorizaton Management Program (FedRAMP) logo" /><br>
				Federal&nbsp;Risk&nbsp;and&nbsp;Authorization&nbsp;Management&nbsp;Program</a>
			</td>
			<td style='width: 2%;'>&nbsp;</td>
		</tr>
		</table>
	</div>
</footer>