<!-- BUGS: Please use this template -->
<!-- QUESTIONS: This is not a general support forum! Ask Qs at http://stackoverflow.com/questions/tagged/jodit -->

**Jodit Version:**  3.1.xxxxx

**Code**

```ts
// A *self-contained* demonstration of the problem follows...
```

**Expected behavior:**

**Actual behavior:**
