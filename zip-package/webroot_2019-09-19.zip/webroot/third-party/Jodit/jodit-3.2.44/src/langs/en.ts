import { IDictionary } from '../types';

export default {
    'Type something': 'Start writing...',
} as IDictionary<string>;
